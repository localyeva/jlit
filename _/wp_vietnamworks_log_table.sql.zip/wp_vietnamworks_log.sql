-- phpMyAdmin SQL Dump
-- version 3.4.10.1deb1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Oct 30, 2015 at 02:19 PM
-- Server version: 5.5.46
-- PHP Version: 5.5.30-1+deb.sury.org~precise+1

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `evajlit`
--

-- --------------------------------------------------------

--
-- Table structure for table `wp_vietnamworks_log`
--

CREATE TABLE IF NOT EXISTS `wp_vietnamworks_log` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `code` int(11) NOT NULL,
  `message` text COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=10 ;

--
-- Dumping data for table `wp_vietnamworks_log`
--

INSERT INTO `wp_vietnamworks_log` (`id`, `email`, `code`, `message`, `created_at`) VALUES
(1, 'haudv@evolableasia.vn', 400, 'Field ''genderid'' is invalid.', '0000-00-00 00:00:00'),
(2, 'haudv@evolableasia.vn', 400, 'Field ''genderid'' is invalid.', '0000-00-00 00:00:00'),
(3, 'haudv@evolableasia.vn', 400, 'Field ''genderid'' is invalid.', '0000-00-00 00:00:00'),
(4, 'haudv@evolableasia.vn', 400, 'Field ''genderid'' is invalid.', '0000-00-00 00:00:00'),
(5, 'haudv@evolableasia.vn', 400, 'Field ''genderid'' is invalid.', '0000-00-00 00:00:00'),
(6, 'haudv@evolableasia.vn', 400, 'Field ''genderid'' is invalid.', '0000-00-00 00:00:00'),
(7, 'haudv@evolableasia.vn', 200, 'Success\nNew userID: 3769328', '0000-00-00 00:00:00'),
(8, 'haudv1@evolableasia.vn', 200, 'Success\nNew userID: 3769329', '2015-10-30 06:52:57'),
(9, 'haudv2@evolableasia.vn', 200, 'Success\nNew userID: 3769330', '2015-10-30 07:07:05');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
